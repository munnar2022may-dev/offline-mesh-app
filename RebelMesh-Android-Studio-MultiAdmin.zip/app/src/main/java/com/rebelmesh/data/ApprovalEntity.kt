package com.rebelmesh.p2p.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

// -----------------------------------------------------------------------------
// 1. Admin Entity: Stores Trusted Admin Nodes & Public Keys
// -----------------------------------------------------------------------------

@Entity(tableName = "trusted_admins")
data class AdminEntity(
    @PrimaryKey
    val adminId: String,
    val displayName: String,
    val publicKeyBase64: String,
    val keyFingerprint: String,
    val addedAtTimestamp: Long = System.currentTimeMillis(),
    val isRootAdmin: Boolean = false,
    val addedByAdminId: String? = null
)

// -----------------------------------------------------------------------------
// 2. Approval Request Entity: Tracks Incoming Join Requests from Pending Peers
// -----------------------------------------------------------------------------

@Entity(tableName = "approval_requests")
data class ApprovalRequestEntity(
    @PrimaryKey
    val userId: String,
    val username: String,
    val userPublicKeyBase64: String,
    val keyFingerprint: String,
    val deviceModel: String,
    val timestamp: Long,
    val status: String = "PENDING", // PENDING, APPROVED, REJECTED
    val receivedViaNodeId: String,
    val hopCount: Int = 1,
    val approvedByAdminId: String? = null,
    val reviewedAtTimestamp: Long? = null
)

// -----------------------------------------------------------------------------
// 3. Approval Token Entity: Stores Cryptographic Tokens Issued by Admins
// -----------------------------------------------------------------------------

@Entity(tableName = "approval_tokens")
data class ApprovalTokenEntity(
    @PrimaryKey
    val userId: String,
    val approvedByAdminId: String,
    val issuedAtTimestamp: Long,
    val signatureBase64: String,
    val isVerifiedLocally: Boolean = true,
    val rawCanonicalPayload: String
)

// -----------------------------------------------------------------------------
// 4. Local User State Entity: Stores whether THIS device is authorized / admin
// -----------------------------------------------------------------------------

@Entity(tableName = "local_user_state")
data class LocalUserStateEntity(
    @PrimaryKey
    val userId: String,
    val username: String,
    val publicKeyBase64: String,
    val keyFingerprint: String,
    val isApproved: Boolean = false,
    val isAdmin: Boolean = false,
    val approvalTokenSignature: String? = null,
    val approvedByAdminId: String? = null,
    val approvedAtTimestamp: Long? = null
)

// -----------------------------------------------------------------------------
// Room DAOs
// -----------------------------------------------------------------------------

@Dao
interface AdminDao {

    @Query("SELECT * FROM trusted_admins ORDER BY addedAtTimestamp ASC")
    fun getAllAdminsFlow(): Flow<List<AdminEntity>>

    @Query("SELECT * FROM trusted_admins WHERE adminId = :adminId LIMIT 1")
    suspend fun getAdminById(adminId: String): AdminEntity?

    @Query("SELECT * FROM trusted_admins WHERE publicKeyBase64 = :publicKeyBase64 LIMIT 1")
    suspend fun getAdminByPublicKey(publicKeyBase64: String): AdminEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAdmin(admin: AdminEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAdmins(admins: List<AdminEntity>)

    @Query("SELECT COUNT(*) FROM trusted_admins WHERE adminId = :adminId")
    suspend fun isAdminTrusted(adminId: String): Int

    @Query("DELETE FROM trusted_admins WHERE adminId = :adminId AND isRootAdmin = 0")
    suspend fun removeAdmin(adminId: String)
}

@Dao
interface ApprovalRequestDao {

    @Query("SELECT * FROM approval_requests ORDER BY timestamp DESC")
    fun getAllRequestsFlow(): Flow<List<ApprovalRequestEntity>>

    @Query("SELECT * FROM approval_requests WHERE status = 'PENDING' ORDER BY timestamp DESC")
    fun getPendingRequestsFlow(): Flow<List<ApprovalRequestEntity>>

    @Query("SELECT * FROM approval_requests WHERE userId = :userId LIMIT 1")
    suspend fun getRequestByUserId(userId: String): ApprovalRequestEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRequest(request: ApprovalRequestEntity)

    @Query("UPDATE approval_requests SET status = :status, approvedByAdminId = :adminId, reviewedAtTimestamp = :timestamp WHERE userId = :userId")
    suspend fun updateRequestStatus(userId: String, status: String, adminId: String, timestamp: Long)

    @Query("DELETE FROM approval_requests WHERE userId = :userId")
    suspend fun deleteRequest(userId: String)
}

@Dao
interface ApprovalTokenDao {

    @Query("SELECT * FROM approval_tokens WHERE userId = :userId LIMIT 1")
    suspend fun getTokenForUser(userId: String): ApprovalTokenEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertToken(token: ApprovalTokenEntity)

    // Local user state queries
    @Query("SELECT * FROM local_user_state LIMIT 1")
    fun getLocalUserStateFlow(): Flow<LocalUserStateEntity?>

    @Query("SELECT * FROM local_user_state LIMIT 1")
    suspend fun getLocalUserState(): LocalUserStateEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveLocalUserState(state: LocalUserStateEntity)

    @Query("UPDATE local_user_state SET isApproved = :isApproved, approvalTokenSignature = :signature, approvedByAdminId = :adminId, approvedAtTimestamp = :timestamp WHERE userId = :userId")
    suspend fun markUserApproved(userId: String, isApproved: Boolean, signature: String, adminId: String, timestamp: Long)

    @Query("UPDATE local_user_state SET isAdmin = :isAdmin WHERE userId = :userId")
    suspend fun setAdminRole(userId: String, isAdmin: Boolean)
}
