package com.rebelmesh.p2p.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

/**
 * Message Entity representing local SQLite storage for chat communications.
 * Includes hop count, delivery acknowledgment state, and route path trace.
 */
@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val packetId: String,
    val conversationPeerId: String,
    val senderId: String,
    val recipientId: String,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isOutgoing: Boolean,
    val isDelivered: Boolean = false,
    val hopCount: Int = 1,
    val routeTrace: String = "Direct"
)

/**
 * Peer Entity storing discovered RebelMesh participants, their RSA-2048 public keys,
 * active Nearby Connections endpointIds, and connectivity status.
 */
@Entity(tableName = "peers")
data class PeerEntity(
    @PrimaryKey
    val peerId: String,
    val displayName: String,
    val publicKeyBase64: String,
    val endpointId: String? = null,
    val isConnected: Boolean = false,
    val lastSeenTimestamp: Long = System.currentTimeMillis()
)

/**
 * Store-and-Forward Relay Queue Entity:
 * Stores encrypted mesh packets destined for peers currently out of radio range.
 * When a disconnected peer is rediscovered, this queue is queried and pushed.
 */
@Entity(tableName = "pending_relays")
data class PendingRelayEntity(
    @PrimaryKey
    val packetId: String,
    val recipientId: String,
    val rawPacketJson: String,
    val ttl: Int,
    val createdAt: Long = System.currentTimeMillis(),
    val retryCount: Int = 0
)

/**
 * Cryptographic Key Pair entity for storing the node's persistent RSA-2048 identity.
 */
@Entity(tableName = "key_pairs")
data class KeyPairEntity(
    @PrimaryKey
    val alias: String,
    val publicKeyBase64: String,
    val privateKeyBase64: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface MessageDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: MessageEntity): Long

    @Query("UPDATE messages SET isDelivered = :isDelivered WHERE packetId = :packetId")
    suspend fun updateDeliveryStatus(packetId: String, isDelivered: Boolean)

    @Query("SELECT * FROM messages WHERE conversationPeerId = :peerId ORDER BY timestamp ASC")
    fun getMessagesForConversation(peerId: String): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages ORDER BY timestamp DESC")
    fun getAllMessages(): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE recipientId = :recipientId AND isDelivered = 0 AND isOutgoing = 1")
    suspend fun getUndeliveredMessagesForRecipient(recipientId: String): List<MessageEntity>

    @Query("SELECT * FROM messages WHERE packetId = :packetId LIMIT 1")
    suspend fun getMessageByPacketId(packetId: String): MessageEntity?
}

@Dao
interface PeerDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPeer(peer: PeerEntity)

    @Query("SELECT * FROM peers WHERE peerId = :peerId LIMIT 1")
    suspend fun getPeer(peerId: String): PeerEntity?

    @Query("SELECT * FROM peers ORDER BY isConnected DESC, lastSeenTimestamp DESC")
    fun getAllPeers(): Flow<List<PeerEntity>>

    @Query("SELECT * FROM peers WHERE isConnected = 1")
    fun getConnectedPeers(): Flow<List<PeerEntity>>

    @Query("UPDATE peers SET isConnected = :isConnected, endpointId = :endpointId, lastSeenTimestamp = :timestamp WHERE peerId = :peerId")
    suspend fun updateConnectionStatus(peerId: String, isConnected: Boolean, endpointId: String?, timestamp: Long)

    @Query("UPDATE peers SET isConnected = 0, endpointId = NULL")
    suspend fun markAllDisconnected()
}

@Dao
interface PendingRelayDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPending(pending: PendingRelayEntity)

    @Query("SELECT * FROM pending_relays WHERE recipientId = :recipientId ORDER BY createdAt ASC")
    suspend fun getPendingForRecipient(recipientId: String): List<PendingRelayEntity>

    @Query("SELECT * FROM pending_relays ORDER BY createdAt DESC")
    fun getAllPending(): Flow<List<PendingRelayEntity>>

    @Query("DELETE FROM pending_relays WHERE packetId = :packetId")
    suspend fun deletePending(packetId: String)

    @Query("DELETE FROM pending_relays WHERE createdAt < :cutoffTimestamp")
    suspend fun pruneExpired(cutoffTimestamp: Long)
}

@Dao
interface KeyPairDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveKeyPair(entity: KeyPairEntity)

    @Query("SELECT * FROM key_pairs WHERE alias = :alias LIMIT 1")
    suspend fun getKeyPair(alias: String): KeyPairEntity?
}

@Database(
    entities = [
        MessageEntity::class,
        PeerEntity::class,
        PendingRelayEntity::class,
        KeyPairEntity::class,
        AdminEntity::class,
        ApprovalRequestEntity::class,
        ApprovalTokenEntity::class,
        LocalUserStateEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class MeshDatabase : RoomDatabase() {

    abstract fun messageDao(): MessageDao
    abstract fun peerDao(): PeerDao
    abstract fun pendingRelayDao(): PendingRelayDao
    abstract fun keyPairDao(): KeyPairDao
    abstract fun adminDao(): AdminDao
    abstract fun approvalRequestDao(): ApprovalRequestDao
    abstract fun approvalTokenDao(): ApprovalTokenDao

    companion object {
        @Volatile
        private var INSTANCE: MeshDatabase? = null

        fun getDatabase(context: Context): MeshDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    MeshDatabase::class.java,
                    "rebel_mesh_database.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
