package com.rebelmesh.p2p.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import com.rebelmesh.p2p.MainActivity
import com.rebelmesh.p2p.mesh.MeshManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach

/**
 * RebelMesh Android Foreground Service.
 * Runs with foregroundServiceType="connectedDevice" to maintain continuous
 * Bluetooth Low Energy (BLE) scanning, Wi-Fi Direct clustering, and multi-hop
 * packet relaying in background or screen-locked states.
 */
class MeshForegroundService : Service() {

    companion object {
        private const val TAG = "RebelMeshService"
        const val CHANNEL_ID = "rebel_mesh_active_channel"
        const val NOTIFICATION_ID = 2002

        const val ACTION_START_SERVICE = "com.rebelmesh.p2p.START_SERVICE"
        const val ACTION_STOP_SERVICE = "com.rebelmesh.p2p.STOP_SERVICE"

        fun start(context: Context) {
            val intent = Intent(context, MeshForegroundService::class.java).apply {
                action = ACTION_START_SERVICE
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, MeshForegroundService::class.java).apply {
                action = ACTION_STOP_SERVICE
            }
            context.startService(intent)
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val binder = LocalBinder()
    private var wakeLock: PowerManager.WakeLock? = null
    private lateinit var meshManager: MeshManager
    private lateinit var notificationManager: NotificationManager

    inner class LocalBinder : Binder() {
        fun getService(): MeshForegroundService = this@MeshForegroundService
        fun getMeshManager(): MeshManager = meshManager
    }

    override fun onCreate() {
        super.onCreate()
        Log.i(TAG, "Creating RebelMesh Foreground Service")
        meshManager = MeshManager.getInstance(applicationContext)
        meshManager.initialize()

        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        createNotificationChannel()
        acquireWakeLock()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_SERVICE -> {
                Log.i(TAG, "Received STOP_SERVICE intent")
                meshManager.stopMesh()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                startForegroundWithNotification()
                meshManager.startMesh()
                observePeerCount()
            }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onDestroy() {
        Log.i(TAG, "Destroying RebelMesh Foreground Service")
        meshManager.stopMesh()
        serviceScope.cancel()
        releaseWakeLock()
        super.onDestroy()
    }

    private fun startForegroundWithNotification() {
        val notification = buildNotification(peerCount = meshManager.connectedPeersCount.value)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun observePeerCount() {
        meshManager.connectedPeersCount
            .onEach { count ->
                val notification = buildNotification(peerCount = count)
                notificationManager.notify(NOTIFICATION_ID, notification)
            }
            .launchIn(serviceScope)
    }

    private fun buildNotification(peerCount: Int): Notification {
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPendingIntent = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, MeshForegroundService::class.java).apply {
            action = ACTION_STOP_SERVICE
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val statusText = if (peerCount == 0) {
            "RebelMesh Active: Discovering offline nodes nearby..."
        } else {
            "Connected to $peerCount node${if (peerCount == 1) "" else "s"} · Multi-Hop Relay Active"
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("RebelMesh Active")
            .setContentText(statusText)
            .setSubText("Offline P2P Mesh")
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setContentIntent(contentPendingIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop Mesh", stopPendingIntent)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "RebelMesh Background Relay Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Maintains offline peer connections and Store-and-Forward routing in background"
                setShowBadge(false)
            }
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun acquireWakeLock() {
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "RebelMesh::RelayWakeLock"
        ).apply {
            setReferenceCounted(false)
            acquire(12 * 60 * 60 * 1000L) // 12-hour safe ceiling
        }
    }

    private fun releaseWakeLock() {
        try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error releasing wake lock", e)
        }
    }
}
