package com.rebelmesh.p2p.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.rebelmesh.p2p.data.MessageEntity
import com.rebelmesh.p2p.data.MeshDatabase
import com.rebelmesh.p2p.data.PeerEntity
import com.rebelmesh.p2p.mesh.MeshEvent
import com.rebelmesh.p2p.mesh.MeshManager
import com.rebelmesh.p2p.service.MeshForegroundService
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * Immutable State representation for Jetpack Compose UI.
 */
data class MeshUiState(
    val myPeerId: String = "",
    val myDisplayName: String = "",
    val isMeshActive: Boolean = false,
    val connectedPeerCount: Int = 0,
    val isApproved: Boolean = false,
    val isAdmin: Boolean = false,
    val peers: List<PeerEntity> = emptyList(),
    val selectedPeer: PeerEntity? = null,
    val activeConversationMessages: List<MessageEntity> = emptyList(),
    val pendingRelaysCount: Int = 0,
    val hasAllPermissions: Boolean = false,
    val lastEventBanner: String? = null
)

/**
 * Architectural ViewModel binding the RebelMesh Compose Material 3 UI with
 * Room SQLite persistence, Nearby Connections mesh operations, and Foreground Service lifecycle.
 */
class MeshViewModel(application: Application) : AndroidViewModel(application) {

    val database = MeshDatabase.getDatabase(application)
    val meshManager = MeshManager.getInstance(application)

    private val _selectedPeerId = MutableStateFlow<String?>(null)
    private val _hasPermissions = MutableStateFlow(false)
    private val _eventBanner = MutableStateFlow<String?>(null)

    val peersFlow: StateFlow<List<PeerEntity>> = database.peerDao()
        .getAllPeers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingCountFlow: StateFlow<Int> = database.pendingRelayDao()
        .getAllPending()
        .combine(flowOf(Unit)) { list, _ -> list.size }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    @OptIn(ExperimentalCoroutinesApi::class)
    val conversationMessagesFlow: StateFlow<List<MessageEntity>> = _selectedPeerId
        .flatMapLatest { peerId ->
            if (peerId == null) flowOf(emptyList())
            else database.messageDao().getMessagesForConversation(peerId)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val uiState: StateFlow<MeshUiState> = combine(
        meshManager.isMeshRunning,
        meshManager.connectedPeersCount,
        peersFlow,
        _selectedPeerId,
        conversationMessagesFlow,
        pendingCountFlow,
        _hasPermissions,
        _eventBanner
    ) { params ->
        val isRunning = params[0] as Boolean
        val peerCount = params[1] as Int
        @Suppress("UNCHECKED_CAST")
        val peers = params[2] as List<PeerEntity>
        val selectedId = params[3] as String?
        @Suppress("UNCHECKED_CAST")
        val messages = params[4] as List<MessageEntity>
        val pendingCount = params[5] as Int
        val hasPerms = params[6] as Boolean
        val banner = params[7] as String?

        val selectedPeer = peers.find { it.peerId == selectedId }

        MeshUiState(
            myPeerId = meshManager.myPeerId,
            myDisplayName = meshManager.myDisplayName,
            isMeshActive = isRunning,
            connectedPeerCount = peerCount,
            peers = peers,
            selectedPeer = selectedPeer,
            activeConversationMessages = messages,
            pendingRelaysCount = pendingCount,
            hasAllPermissions = hasPerms,
            lastEventBanner = banner
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        MeshUiState()
    )

    init {
        meshManager.initialize()
        observeMeshEvents()
    }

    private fun observeMeshEvents() {
        viewModelScope.launch {
            meshManager.meshEvents.collect { event ->
                val message = when (event) {
                    is MeshEvent.PeerConnected -> "Peer connected: ${event.peer.displayName}"
                    is MeshEvent.PeerDisconnected -> "Peer disconnected (${event.peerId})"
                    is MeshEvent.MessageReceived -> "Decrypted message from ${event.message.senderId}"
                    is MeshEvent.PacketRelayed -> "Relayed packet ${event.packetId.take(6)} (${event.hopsLeft} hops left)"
                    is MeshEvent.DeliveryAckReceived -> "Delivery ACK verified for message"
                }
                _eventBanner.value = message
            }
        }
    }

    fun dismissBanner() {
        _eventBanner.value = null
    }

    fun setPermissionsGranted(granted: Boolean) {
        _hasPermissions.value = granted
        if (granted && !meshManager.isMeshRunning.value) {
            startMeshService()
        }
    }

    fun selectPeer(peer: PeerEntity?) {
        _selectedPeerId.value = peer?.peerId
    }

    fun startMeshService() {
        MeshForegroundService.start(getApplication())
    }

    fun stopMeshService() {
        MeshForegroundService.stop(getApplication())
    }

    fun toggleMeshService() {
        if (meshManager.isMeshRunning.value) {
            stopMeshService()
        } else {
            startMeshService()
        }
    }

    fun sendMessage(text: String) {
        val currentPeer = uiState.value.selectedPeer ?: return
        if (text.isBlank()) return

        meshManager.sendMessage(currentPeer, text) { success ->
            if (!success) {
                _eventBanner.value = "Failed to encrypt/send message"
            }
        }
    }
}
