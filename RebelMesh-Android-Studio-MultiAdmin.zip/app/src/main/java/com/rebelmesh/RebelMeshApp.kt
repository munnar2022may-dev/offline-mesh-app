package com.rebelmesh.p2p
import android.app.Application
import com.rebelmesh.p2p.data.MeshDatabase
import com.rebelmesh.p2p.mesh.MeshManager
class RebelMeshApp : Application() {
  override fun onCreate() { super.onCreate(); MeshDatabase.getDatabase(this); MeshManager.getInstance(this).initialize() }
}