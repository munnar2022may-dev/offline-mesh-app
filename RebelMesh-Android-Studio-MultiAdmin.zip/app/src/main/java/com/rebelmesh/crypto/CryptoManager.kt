package com.rebelmesh.p2p.crypto

import android.util.Base64
import java.nio.charset.StandardCharsets
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.PublicKey
import java.security.SecureRandom
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import kotlinx.serialization.Serializable

/**
 * Encrypted payload containing hybrid cryptography components:
 * - encryptedAesKey: 256-bit AES key encrypted with recipient's RSA-2048 public key (OAEP-SHA256)
 * - iv: 12-byte initialization vector for AES-GCM (Base64)
 * - ciphertext: Message payload encrypted with AES-256-GCM + 128-bit authentication tag (Base64)
 *
 * Intermediate relay nodes in the RebelMesh network can ONLY read outer routing metadata.
 * The message payload remains completely zero-knowledge ciphertext to any intermediate hop.
 */
@Serializable
data class EncryptedPayload(
    val encryptedAesKey: String,
    val iv: String,
    val ciphertext: String
)

/**
 * RebelMesh Cryptographic Engine:
 * Implements military-grade End-to-End Encryption (E2EE) using Hybrid Cryptography:
 * RSA-2048 (OAEP-SHA256) for Key Encapsulation and AES-256-GCM for Authenticated Payload Encryption.
 */
object CryptoManager {

    private const val RSA_ALGORITHM = "RSA"
    private const val RSA_TRANSFORMATION = "RSA/ECB/OAEPWithSHA-256AndMGF1Padding"
    private const val RSA_KEY_SIZE = 2048

    private const val AES_ALGORITHM = "AES"
    private const val AES_TRANSFORMATION = "AES/GCM/NoPadding"
    private const val AES_KEY_SIZE = 256
    private const val GCM_IV_LENGTH_BYTES = 12
    private const val GCM_TAG_LENGTH_BITS = 128

    private val secureRandom = SecureRandom()

    /**
     * Generates a persistent RSA 2048-bit key pair for this RebelMesh node.
     */
    fun generateRsaKeyPair(): KeyPair {
        val keyPairGenerator = KeyPairGenerator.getInstance(RSA_ALGORITHM)
        keyPairGenerator.initialize(RSA_KEY_SIZE, secureRandom)
        return keyPairGenerator.generateKeyPair()
    }

    /**
     * Encodes Public Key to X.509 Base64 string for transmission during P2P handshake.
     */
    fun exportPublicKey(publicKey: PublicKey): String {
        return Base64.encodeToString(publicKey.encoded, Base64.NO_WRAP)
    }

    /**
     * Encodes Private Key to PKCS#8 Base64 string for secure Room database storage.
     */
    fun exportPrivateKey(privateKey: PrivateKey): String {
        return Base64.encodeToString(privateKey.encoded, Base64.NO_WRAP)
    }

    /**
     * Reconstructs PublicKey from X.509 Base64 string received from mesh peer.
     */
    fun importPublicKey(base64PublicKey: String): PublicKey {
        val keyBytes = Base64.decode(base64PublicKey, Base64.NO_WRAP)
        val keySpec = X509EncodedKeySpec(keyBytes)
        val keyFactory = KeyFactory.getInstance(RSA_ALGORITHM)
        return keyFactory.generatePublic(keySpec)
    }

    /**
     * Reconstructs PrivateKey from PKCS#8 Base64 string retrieved from local Room database.
     */
    fun importPrivateKey(base64PrivateKey: String): PrivateKey {
        val keyBytes = Base64.decode(base64PrivateKey, Base64.NO_WRAP)
        val keySpec = PKCS8EncodedKeySpec(keyBytes)
        val keyFactory = KeyFactory.getInstance(RSA_ALGORITHM)
        return keyFactory.generatePrivate(keySpec)
    }

    /**
     * Generates a fresh ephemeral 256-bit AES symmetric key.
     */
    fun generateEphemeralAesKey(): SecretKey {
        val keyGen = KeyGenerator.getInstance(AES_ALGORITHM)
        keyGen.init(AES_KEY_SIZE, secureRandom)
        return keyGen.generateKey()
    }

    /**
     * Computes a friendly 8-character hex fingerprint of an RSA public key (e.g. "7B21:4A9F").
     */
    fun getFingerprint(publicKey: PublicKey): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val hash = digest.digest(publicKey.encoded)
        return hash.take(4).joinToString(":") { "%02X".format(it) }
    }

    /**
     * Hybrid Encryption:
     * 1. Generates ephemeral 256-bit AES symmetric key.
     * 2. Encrypts plaintext with AES-256-GCM using 12-byte random IV.
     * 3. Encrypts ephemeral AES key with recipient's RSA-2048 public key (OAEP-SHA256).
     *
     * @param plaintext UTF-8 string to encrypt.
     * @param recipientPublicKey The public key of the final destination peer.
     * @return EncryptedPayload containing ciphertext, IV, and wrapped AES key.
     */
    fun encryptHybrid(plaintext: String, recipientPublicKey: PublicKey): EncryptedPayload {
        // Step 1: Generate ephemeral AES-256 key
        val ephemeralAesKey = generateEphemeralAesKey()

        // Step 2: Encrypt message payload with AES-256-GCM
        val iv = ByteArray(GCM_IV_LENGTH_BYTES).apply { secureRandom.nextBytes(this) }
        val gcmSpec = GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv)
        val aesCipher = Cipher.getInstance(AES_TRANSFORMATION)
        aesCipher.init(Cipher.ENCRYPT_MODE, ephemeralAesKey, gcmSpec)
        val ciphertextBytes = aesCipher.doFinal(plaintext.toByteArray(StandardCharsets.UTF_8))

        // Step 3: Wrap ephemeral AES key with recipient's RSA Public Key (OAEP-SHA256)
        val rsaCipher = Cipher.getInstance(RSA_TRANSFORMATION)
        rsaCipher.init(Cipher.ENCRYPT_MODE, recipientPublicKey)
        val encryptedAesKeyBytes = rsaCipher.doFinal(ephemeralAesKey.encoded)

        return EncryptedPayload(
            encryptedAesKey = Base64.encodeToString(encryptedAesKeyBytes, Base64.NO_WRAP),
            iv = Base64.encodeToString(iv, Base64.NO_WRAP),
            ciphertext = Base64.encodeToString(ciphertextBytes, Base64.NO_WRAP)
        )
    }

    /**
     * Hybrid Decryption:
     * 1. Unwraps ephemeral AES key using own RSA Private Key.
     * 2. Decrypts AES-256-GCM ciphertext and validates 128-bit authentication tag.
     *
     * Throws javax.crypto.AEADBadTagException if ciphertext was tampered with in transit.
     *
     * @param payload EncryptedPayload received over the mesh.
     * @param myPrivateKey The device's own private key.
     * @return Original plaintext UTF-8 string.
     */
    fun decryptHybrid(payload: EncryptedPayload, myPrivateKey: PrivateKey): String {
        // Step 1: Decrypt ephemeral AES key using RSA Private Key
        val rsaCipher = Cipher.getInstance(RSA_TRANSFORMATION)
        rsaCipher.init(Cipher.DECRYPT_MODE, myPrivateKey)
        val encryptedAesKeyBytes = Base64.decode(payload.encryptedAesKey, Base64.NO_WRAP)
        val rawAesKeyBytes = rsaCipher.doFinal(encryptedAesKeyBytes)
        val recoveredAesKey = SecretKeySpec(rawAesKeyBytes, AES_ALGORITHM)

        // Step 2: Decrypt payload using AES-256-GCM
        val ivBytes = Base64.decode(payload.iv, Base64.NO_WRAP)
        val ciphertextBytes = Base64.decode(payload.ciphertext, Base64.NO_WRAP)
        val gcmSpec = GCMParameterSpec(GCM_TAG_LENGTH_BITS, ivBytes)

        val aesCipher = Cipher.getInstance(AES_TRANSFORMATION)
        aesCipher.init(Cipher.DECRYPT_MODE, recoveredAesKey, gcmSpec)
        val decryptedBytes = aesCipher.doFinal(ciphertextBytes)

        return String(decryptedBytes, StandardCharsets.UTF_8)
    }
}
