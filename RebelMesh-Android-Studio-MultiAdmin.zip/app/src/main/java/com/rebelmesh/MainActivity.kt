package com.rebelmesh.p2p

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.WifiTethering
import androidx.compose.material.icons.filled.WifiTetheringOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.rebelmesh.p2p.data.MessageEntity
import com.rebelmesh.p2p.data.PeerEntity
import com.rebelmesh.p2p.ui.MeshViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val viewModel: MeshViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            RebelMeshTheme {
                val isApproved by viewModel.meshManager.isApproved.collectAsState()
                val isAdmin by viewModel.meshManager.isAdmin.collectAsState()
                var showAdminDashboard by remember { mutableStateOf(false) }

                if (!isApproved) {
                    com.rebelmesh.p2p.ui.PendingApprovalScreen(
                        meshManager = viewModel.meshManager,
                        onApprovedAndUnlocked = {
                            // Automatically advances to main screen
                        }
                    )
                } else if (showAdminDashboard && isAdmin) {
                    com.rebelmesh.p2p.ui.AdminDashboardScreen(
                        meshManager = viewModel.meshManager,
                        adminId = viewModel.meshManager.myPeerId,
                        onNavigateBack = { showAdminDashboard = false }
                    )
                } else {
                    RebelMeshAppScreen(
                        viewModel = viewModel,
                        isAdmin = isAdmin,
                        onOpenAdminDashboard = { showAdminDashboard = true }
                    )
                }
            }
        }
    }
}

// -----------------------------------------------------------------------------
// Jetpack Compose Material 3 Theme (Rebel 20% Darker Dark Rainbow)
// -----------------------------------------------------------------------------

private val RebelDarkRainbowColors = darkColorScheme(
    primary = Color(0xFF362DA2), // Deep Indigo (20% darker)
    onPrimary = Color(0xFFE2E8F0),
    primaryContainer = Color(0xFF1E1B4B),
    onPrimaryContainer = Color(0xFFDDD6FE),
    secondary = Color(0xFF036046), // Deep Emerald (20% darker)
    onSecondary = Color(0xFFF0FDF4),
    tertiary = Color(0xFF980E30), // Deep Crimson (20% darker)
    onTertiary = Color(0xFFFFF1F2),
    background = Color(0xFF020204), // Obsidian Pitch Black (20% darker)
    surface = Color(0xFF05070D),
    surfaceVariant = Color(0xFF0D121F),
    onSurface = Color(0xFFE2E8F0),
    onSurfaceVariant = Color(0xFF64748B)
)

val DarkRainbowGradient = androidx.compose.ui.graphics.Brush.horizontalGradient(
    listOf(
        Color(0xFF980E30), // Deep Crimson (20% darker)
        Color(0xFF904207), // Deep Amber (20% darker)
        Color(0xFF036046), // Deep Emerald (20% darker)
        Color(0xFF0B5D73), // Deep Cyan (20% darker)
        Color(0xFF362DA2), // Deep Indigo (20% darker)
        Color(0xFF561A86)  // Deep Violet (20% darker)
    )
)

@Composable
fun RebelMeshTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = RebelDarkRainbowColors,
        content = content
    )
}

// -----------------------------------------------------------------------------
// Main Scaffold & Permission Handling
// -----------------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RebelMeshAppScreen(
    viewModel: MeshViewModel,
    isAdmin: Boolean = false,
    onOpenAdminDashboard: () -> Unit = {}
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    var showKeyDetailsDialog by remember { mutableStateOf(false) }

    // Required Android Permissions list based on SDK Level
    val requiredPermissions = remember {
        val list = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            list.add(Manifest.permission.POST_NOTIFICATIONS)
            list.add(Manifest.permission.NEARBY_WIFI_DEVICES)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            list.add(Manifest.permission.BLUETOOTH_SCAN)
            list.add(Manifest.permission.BLUETOOTH_ADVERTISE)
            list.add(Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            list.add(Manifest.permission.ACCESS_FINE_LOCATION)
            list.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        }
        list.toTypedArray()
    }

    // Runtime Permission Launcher
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val allGranted = results.all { it.value }
        viewModel.setPermissionsGranted(allGranted)
        if (!allGranted) {
            scope.launch {
                snackbarHostState.showSnackbar("Nearby permissions required for offline mesh operation.")
            }
        }
    }

    // Check permissions on initial launch
    LaunchedEffect(Unit) {
        val hasAll = requiredPermissions.all { perm ->
            ContextCompat.checkSelfPermission(context, perm) == PackageManager.PERMISSION_GRANTED
        }
        viewModel.setPermissionsGranted(hasAll)
        if (!hasAll) {
            permissionLauncher.launch(requiredPermissions)
        }
    }

    // Event Banner Snackbar
    LaunchedEffect(uiState.lastEventBanner) {
        uiState.lastEventBanner?.let { banner ->
            snackbarHostState.showSnackbar(banner)
            viewModel.dismissBanner()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            CenterAlignedTopAppBar(
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                title = {
                    Column(horizontalAlignment = Alignment.CenterAlignmentHorizontally) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "RebelMesh",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            // E2EE Verified badge
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = "E2EE Verified",
                                modifier = Modifier
                                    .size(16.dp)
                                    .clickable { showKeyDetailsDialog = true },
                                tint = MaterialTheme.colorScheme.secondary
                            )
                        }
                        Text(
                            text = "${uiState.myDisplayName} · ${uiState.connectedPeerCount} direct peer${if (uiState.connectedPeerCount == 1) "" else "s"}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    if (isAdmin) {
                        IconButton(onClick = onOpenAdminDashboard) {
                            Icon(
                                imageVector = Icons.Default.AdminPanelSettings,
                                contentDescription = "Admin Dashboard",
                                tint = Color(0xFFF43F5E)
                            )
                        }
                    }
                    IconButton(onClick = { viewModel.toggleMeshService() }) {
                        Icon(
                            imageVector = if (uiState.isMeshActive) Icons.Default.WifiTethering else Icons.Default.WifiTetheringOff,
                            contentDescription = "Toggle Mesh",
                            tint = if (uiState.isMeshActive) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Permission missing notice
            if (!uiState.hasAllPermissions) {
                PermissionWarningCard(onGrantClick = { permissionLauncher.launch(requiredPermissions) })
            }

            // Store-and-Forward pending queue indicator
            if (uiState.pendingRelaysCount > 0) {
                StoreAndForwardQueueCard(pendingCount = uiState.pendingRelaysCount)
            }

            // Peers Carousel Selector
            PeerSelectorRow(
                peers = uiState.peers,
                selectedPeer = uiState.selectedPeer,
                onPeerSelected = { viewModel.selectPeer(it) }
            )

            // Conversation Chat View or Empty State
            if (uiState.selectedPeer != null) {
                ChatConversationPane(
                    peer = uiState.selectedPeer!!,
                    messages = uiState.activeConversationMessages,
                    onSendMessage = { viewModel.sendMessage(it) },
                    onShowKeyDetails = { showKeyDetailsDialog = true },
                    modifier = Modifier.weight(1f)
                )
            } else {
                EmptyPeerPlaceholder(
                    peerCount = uiState.peers.size,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }

    if (showKeyDetailsDialog) {
        KeyDetailsDialog(
            myPeerId = uiState.myPeerId,
            selectedPeer = uiState.selectedPeer,
            onDismiss = { showKeyDetailsDialog = false }
        )
    }
}

// -----------------------------------------------------------------------------
// Component: Peer Selector Row
// -----------------------------------------------------------------------------

@Composable
fun PeerSelectorRow(
    peers: List<PeerEntity>,
    selectedPeer: PeerEntity?,
    onPeerSelected: (PeerEntity) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .padding(vertical = 8.dp)
    ) {
        Text(
            text = "DISCOVERED PEERS (${peers.size})",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )

        if (peers.isEmpty()) {
            Text(
                text = "Scanning nearby BLE & Wi-Fi Direct radios...",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
            )
        } else {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(peers, key = { it.peerId }) { peer ->
                    val isSelected = peer.peerId == selectedPeer?.peerId
                    PeerChip(
                        peer = peer,
                        isSelected = isSelected,
                        onClick = { onPeerSelected(peer) }
                    )
                }
            }
        }
    }
}

@Composable
fun PeerChip(
    peer: PeerEntity,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val borderColor = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent
    val surfaceColor = if (isSelected) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface

    Card(
        modifier = Modifier
            .clickable { onClick() }
            .border(1.dp, borderColor, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = surfaceColor),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(if (peer.isConnected) MaterialTheme.colorScheme.secondary else Color(0xFF6B7280))
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = peer.displayName,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = if (peer.isConnected) "Direct Link" else "Offline / Multi-hop",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (peer.isConnected) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

// -----------------------------------------------------------------------------
// Component: Chat Conversation Pane
// -----------------------------------------------------------------------------

@Composable
fun ChatConversationPane(
    peer: PeerEntity,
    messages: List<MessageEntity>,
    onSendMessage: (String) -> Unit,
    onShowKeyDetails: () -> Unit,
    modifier: Modifier = Modifier
) {
    var textInput by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "Encrypted",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "RSA-2048 / AES-256-GCM End-to-End Encrypted",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(
                text = "Fingerprint",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable { onShowKeyDetails() }
            )
        }

        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) {
            items(messages, key = { it.packetId }) { message ->
                MessageBubble(message = message)
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = textInput,
                onValueChange = { textInput = it },
                placeholder = { Text("Type offline message...") },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.surfaceVariant
                ),
                maxLines = 4
            )
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(
                onClick = {
                    if (textInput.isNotBlank()) {
                        onSendMessage(textInput.trim())
                        textInput = ""
                    }
                },
                modifier = Modifier
                    .size(48.dp)
                    .background(MaterialTheme.colorScheme.primary, CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.Send,
                    contentDescription = "Send",
                    tint = MaterialTheme.colorScheme.onPrimary
                )
            }
        }
    }
}

// -----------------------------------------------------------------------------
// Component: Message Bubble
// -----------------------------------------------------------------------------

@Composable
fun MessageBubble(message: MessageEntity) {
    val isOutgoing = message.isOutgoing
    val alignment = if (isOutgoing) Alignment.End else Alignment.Start
    val bubbleColor = if (isOutgoing) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
    val textColor = if (isOutgoing) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface

    val timeFormatter = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    val formattedTime = remember(message.timestamp) { timeFormatter.format(Date(message.timestamp)) }

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = alignment
    ) {
        Card(
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isOutgoing) 16.dp else 2.dp,
                bottomEnd = if (isOutgoing) 2.dp else 16.dp
            ),
            colors = CardDefaults.cardColors(containerColor = bubbleColor),
            modifier = Modifier.width(IntrinsicSize.Max)
        ) {
            Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                Text(
                    text = message.content,
                    style = MaterialTheme.typography.bodyMedium,
                    color = textColor
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.End,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = if (message.hopCount > 1) "${message.hopCount} hops" else "Direct",
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 10.sp,
                        color = textColor.copy(alpha = 0.7f)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = formattedTime,
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 10.sp,
                        color = textColor.copy(alpha = 0.7f)
                    )

                    if (isOutgoing) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = if (message.isDelivered) Icons.Default.DoneAll else Icons.Default.Check,
                            contentDescription = if (message.isDelivered) "Delivered" else "Queued",
                            modifier = Modifier.size(13.dp),
                            tint = if (message.isDelivered) MaterialTheme.colorScheme.secondary else textColor.copy(alpha = 0.7f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun StoreAndForwardQueueCard(pendingCount: Int) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
        shape = RoundedCornerShape(10.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Router,
                contentDescription = "Queue",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = "Store-and-Forward Active",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "$pendingCount encrypted message${if (pendingCount == 1) "" else "s"} stored in Room SQLite awaiting peer proximity.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF94A3B8)
                )
            }
        }
    }
}

@Composable
fun PermissionWarningCard(onGrantClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF7F1D1D)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Nearby Radio Permissions Needed",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "RebelMesh requires Bluetooth and Local Wi-Fi Device permissions to form the offline mesh.",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFFFCA5A5)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Button(
                onClick = onGrantClick,
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Grant Permissions")
            }
        }
    }
}

@Composable
fun EmptyPeerPlaceholder(peerCount: Int, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
            Icon(
                imageVector = Icons.Default.WifiTethering,
                contentDescription = null,
                modifier = Modifier.size(56.dp),
                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = if (peerCount == 0) "Scanning for Offline Mesh Peers" else "Select a Peer to Chat",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = if (peerCount == 0)
                    "Ensure other devices have RebelMesh open with Bluetooth & Wi-Fi enabled. Zero cellular or internet required."
                else
                    "Select any peer from the top carousel to send end-to-end encrypted messages.",
                style = MaterialTheme.typography.bodySmall,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun KeyDetailsDialog(
    myPeerId: String,
    selectedPeer: PeerEntity?,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("RebelMesh Cryptographic Verification", style = MaterialTheme.typography.titleMedium)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "My Node ID:",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = myPeerId,
                    style = MaterialTheme.typography.bodySmall,
                    fontFamily = FontFamily.Monospace
                )

                if (selectedPeer != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Peer Public Key (X.509 Base64):",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = selectedPeer.publicKeyBase64.take(64) + "...",
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Zero-Knowledge Relaying:",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.secondary
                )
                Text(
                    text = "Messages use AES-256-GCM authenticated encryption with the symmetric key wrapped via recipient's RSA-2048 OAEP key. Intermediate nodes can never decrypt content.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}
