package com.rebelmesh.p2p.mesh

import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import org.json.JSONObject

/**
 * Enumeration of Application-Layer Mesh Packet Types supported by RebelMesh.
 */
enum class MeshPacketType {
    CHAT_MESSAGE,
    DELIVERY_ACK,
    JOIN_REQUEST,
    ADMIN_APPROVAL_TOKEN,
    ADMIN_REVOCATION,
    ADMIN_ANNOUNCEMENT
}

/**
 * Payload sent by an unapproved peer broadcasting their decentralized registration request.
 */
@Serializable
data class JoinRequestPayload(
    val userId: String,
    val username: String,
    val userPublicKey: String,
    val timestamp: Long = System.currentTimeMillis(),
    val deviceModel: String = android.os.Build.MODEL ?: "Android Device",
    val status: String = "PENDING"
) {
    fun toJson(): String = Json.encodeToString(this)

    companion object {
        fun fromJson(jsonStr: String): JoinRequestPayload = Json.decodeFromString(jsonStr)
    }
}

/**
 * Cryptographic Approval Token payload issued by an Admin Private Key.
 */
@Serializable
data class ApprovalTokenPayload(
    val userId: String,
    val username: String,
    val approvedByAdminId: String,
    val issuedAtTimestamp: Long,
    val signature: String, // RSA-SHA256 signature over userId + userPublicKey
    val adminPublicKey: String? = null
) {
    fun toJson(): String = Json.encodeToString(this)

    companion object {
        fun fromJson(jsonStr: String): ApprovalTokenPayload = Json.decodeFromString(jsonStr)
    }
}

/**
 * Cryptographic Revocation payload issued by an Admin to ban a peer across the mesh.
 */
@Serializable
data class RevocationPayload(
    val targetUserId: String,
    val revokedByAdminId: String,
    val timestamp: Long,
    val reason: String,
    val signature: String
) {
    fun toJson(): String = Json.encodeToString(this)

    companion object {
        fun fromJson(jsonStr: String): RevocationPayload = Json.decodeFromString(jsonStr)
    }
}

/**
 * Wire-Format Packet Envelope for RebelMesh P2P_CLUSTER transmission.
 *
 * Intermediate relay nodes only inspect the outer routing fields (type, senderId, recipientId, ttl, hopCount).
 * The content remains end-to-end encrypted or digitally signed.
 */
@Serializable
data class MeshPacket(
    val packetId: String,
    val type: MeshPacketType = MeshPacketType.CHAT_MESSAGE,
    val senderId: String,
    val recipientId: String, // Target peerId, or "ADMIN_BROADCAST", or "*" for public broadcast
    val ttl: Int = 3,
    val hopCount: Int = 1,
    val routeTrace: List<String> = emptyList(),
    val payloadJson: String = "",
    val encryptedAesKey: String? = null,
    val iv: String? = null
) {
    fun toBytes(): ByteArray {
        val json = Json { ignoreUnknownKeys = true }
        return json.encodeToString(this).toByteArray(Charsets.UTF_8)
    }

    companion object {
        const val BROADCAST_RECIPIENT_ADMINS = "ADMIN_BROADCAST"
        const val BROADCAST_ALL = "*"

        fun fromBytes(bytes: ByteArray): MeshPacket {
            val jsonStr = String(bytes, Charsets.UTF_8)
            val json = Json { ignoreUnknownKeys = true }
            return json.decodeFromString(jsonStr)
        }
    }
}
