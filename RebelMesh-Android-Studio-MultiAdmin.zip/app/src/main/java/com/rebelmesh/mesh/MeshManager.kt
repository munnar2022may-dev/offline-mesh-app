package com.rebelmesh.p2p.mesh

import android.content.Context
import android.os.Build
import android.util.Log
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsClient
import com.google.android.gms.nearby.connection.ConnectionsStatusCodes
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import com.rebelmesh.p2p.crypto.AdminCryptoManager
import com.rebelmesh.p2p.crypto.CryptoManager
import com.rebelmesh.p2p.crypto.EncryptedPayload
import com.rebelmesh.p2p.data.AdminEntity
import com.rebelmesh.p2p.data.ApprovalRequestEntity
import com.rebelmesh.p2p.data.ApprovalTokenEntity
import com.rebelmesh.p2p.data.KeyPairEntity
import com.rebelmesh.p2p.data.LocalUserStateEntity
import com.rebelmesh.p2p.data.MessageEntity
import com.rebelmesh.p2p.data.MeshDatabase
import com.rebelmesh.p2p.data.PeerEntity
import com.rebelmesh.p2p.data.PendingRelayEntity
import java.nio.charset.StandardCharsets
import java.security.PrivateKey
import java.security.PublicKey
import java.util.Collections
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * Supported Packet Types for RebelMesh Offline P2P Protocol.
 */
@Serializable
enum class PacketType {
    HANDSHAKE,
    DATA,
    ACK,
    JOIN_REQUEST,
    ADMIN_APPROVAL_TOKEN,
    ADMIN_REVOCATION
}

/**
 * Wire-format packet routed across the RebelMesh offline P2P network.
 * Intermediate nodes inspect only the routing fields (packetId, senderId, recipientId, ttl, hopCount).
 */
@Serializable
data class MeshPacket(
    val packetId: String = UUID.randomUUID().toString(),
    val type: PacketType = PacketType.DATA,
    val senderId: String,
    val senderDisplayName: String,
    val recipientId: String,
    val ttl: Int = 3, // Max 3 hops to terminate broadcast loops and prevent network storms
    val hopCount: Int = 0,
    val routeTrace: List<String> = emptyList(),
    val encryptedAesKey: String = "",
    val iv: String = "",
    val ciphertext: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

sealed interface MeshEvent {
    data class PeerConnected(val peer: PeerEntity) : MeshEvent
    data class PeerDisconnected(val peerId: String) : MeshEvent
    data class MessageReceived(val message: MessageEntity) : MeshEvent
    data class PacketRelayed(val packetId: String, val senderId: String, val recipientId: String, val hopsLeft: Int) : MeshEvent
    data class DeliveryAckReceived(val packetId: String) : MeshEvent
    data class JoinRequestReceived(val request: ApprovalRequestEntity) : MeshEvent
    data class UserApproved(val token: ApprovalTokenEntity) : MeshEvent
    data class UserRevoked(val targetUserId: String, val adminId: String) : MeshEvent
}

/**
 * RebelMesh Core Mesh Protocol Manager with Multi-Admin Cryptographic Onboarding.
 *
 * Handles Strategy.P2P_CLUSTER, Store-and-Forward routing, TTL loop suppression,
 * decentralized join request broadcast, admin digital signing, and offline token verification.
 */
class MeshManager private constructor(private val context: Context) {

    companion object {
        private const val TAG = "RebelMeshManager"
        private const val SERVICE_ID = "com.rebelmesh.p2p.SERVICE_CLUSTER"
        private const val MAX_TTL = 3
        private const val KEY_ALIAS = "rebel_mesh_identity_key"
        const val BROADCAST_ADMINS = "ADMIN_BROADCAST"

        @Volatile
        private var INSTANCE: MeshManager? = null

        fun getInstance(context: Context): MeshManager {
            return INSTANCE ?: synchronized(this) {
                val instance = MeshManager(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val connectionsClient: ConnectionsClient = Nearby.getConnectionsClient(context)
    private val database = MeshDatabase.getDatabase(context)

    // Identity state
    var myPeerId: String = ""
        private set
    var myDisplayName: String = "Rebel Node"
        private set
    private lateinit var myPublicKey: PublicKey
    private lateinit var myPrivateKey: PrivateKey
    private var myPublicKeyBase64: String = ""

    // In-memory active direct links: Map<EndpointId, ConnectedPeerInfo>
    data class ConnectedEndpoint(
        val endpointId: String,
        var peerId: String? = null,
        var displayName: String? = null,
        var publicKeyBase64: String? = null
    )

    private val activeEndpoints = ConcurrentHashMap<String, ConnectedEndpoint>()
    private val peerIdToEndpointMap = ConcurrentHashMap<String, String>()

    // Packet deduplication cache
    private val seenPacketIds = Collections.synchronizedSet(LinkedHashSet<String>())
    private val maxSeenPackets = 1000

    // Observables for UI & Foreground Service
    private val _isMeshRunning = MutableStateFlow(false)
    val isMeshRunning: StateFlow<Boolean> = _isMeshRunning.asStateFlow()

    private val _connectedPeersCount = MutableStateFlow(0)
    val connectedPeersCount: StateFlow<Int> = _connectedPeersCount.asStateFlow()

    private val _isApproved = MutableStateFlow(false)
    val isApproved: StateFlow<Boolean> = _isApproved.asStateFlow()

    private val _isAdmin = MutableStateFlow(false)
    val isAdmin: StateFlow<Boolean> = _isAdmin.asStateFlow()

    private val _meshEvents = MutableSharedFlow<MeshEvent>(extraBufferCapacity = 64)
    val meshEvents: SharedFlow<MeshEvent> = _meshEvents.asSharedFlow()

    /**
     * Initializes RSA Key Pair, loads or bootstraps local user onboarding state,
     * seeds Genesis Root Admin if first launch, and cleans up stale connection state.
     */
    fun initialize() {
        scope.launch {
            loadOrGenerateKeys()
            bootstrapLocalUserState()
            database.peerDao().markAllDisconnected()
        }
    }

    private suspend fun loadOrGenerateKeys() {
        val existingKey = database.keyPairDao().getKeyPair(KEY_ALIAS)
        if (existingKey != null) {
            myPublicKey = CryptoManager.importPublicKey(existingKey.publicKeyBase64)
            myPrivateKey = CryptoManager.importPrivateKey(existingKey.privateKeyBase64)
            myPublicKeyBase64 = existingKey.publicKeyBase64
        } else {
            val keyPair = CryptoManager.generateRsaKeyPair()
            myPublicKey = keyPair.public
            myPrivateKey = keyPair.private
            myPublicKeyBase64 = CryptoManager.exportPublicKey(myPublicKey)
            val privateKeyBase64 = CryptoManager.exportPrivateKey(myPrivateKey)

            database.keyPairDao().saveKeyPair(
                KeyPairEntity(
                    alias = KEY_ALIAS,
                    publicKeyBase64 = myPublicKeyBase64,
                    privateKeyBase64 = privateKeyBase64
                )
            )
        }

        val fingerprint = CryptoManager.getFingerprint(myPublicKey)
        myPeerId = "REBEL-${fingerprint.replace(":", "")}"
        myDisplayName = "Rebel ${myPeerId.takeLast(4)}"
        Log.i(TAG, "Initialized RebelMesh node identity: $myPeerId ($myDisplayName)")
    }

    private suspend fun bootstrapLocalUserState() {
        val localState = database.approvalTokenDao().getLocalUserState()
        if (localState != null) {
            _isApproved.value = localState.isApproved
            _isAdmin.value = localState.isAdmin
        } else {
            // First run: Create initial unapproved state
            val fingerprint = CryptoManager.getFingerprint(myPublicKey)
            val newState = LocalUserStateEntity(
                userId = myPeerId,
                username = myDisplayName,
                publicKeyBase64 = myPublicKeyBase64,
                keyFingerprint = fingerprint,
                isApproved = false,
                isAdmin = false
            )
            database.approvalTokenDao().saveLocalUserState(newState)
            _isApproved.value = false
            _isAdmin.value = false

            // Seed default Genesis Admin identity into Room DB
            seedGenesisAdmin()
        }
    }

    private suspend fun seedGenesisAdmin() {
        // Pre-configure root admin trust anchor so new nodes can verify authentic admin signatures
        val existingAdmin = database.adminDao().getAdminById(AdminCryptoManager.DEFAULT_GENESIS_ADMIN_ID)
        if (existingAdmin == null) {
            val genesisAdmin = AdminEntity(
                adminId = AdminCryptoManager.DEFAULT_GENESIS_ADMIN_ID,
                displayName = "Alpha Root Admin",
                publicKeyBase64 = myPublicKeyBase64, // Default fallback to this key if bootstrapped as admin
                keyFingerprint = CryptoManager.getFingerprint(myPublicKey),
                addedAtTimestamp = System.currentTimeMillis(),
                isRootAdmin = true
            )
            database.adminDao().insertAdmin(genesisAdmin)
        }
    }

    /**
     * Designates this local device as an active Admin Node (e.g., during setup or QR scan).
     */
    fun designateAsAdminNode(displayName: String = "Master Admin") {
        scope.launch {
            val fingerprint = CryptoManager.getFingerprint(myPublicKey)
            val adminEntity = AdminEntity(
                adminId = myPeerId,
                displayName = displayName,
                publicKeyBase64 = myPublicKeyBase64,
                keyFingerprint = fingerprint,
                addedAtTimestamp = System.currentTimeMillis(),
                isRootAdmin = true
            )
            database.adminDao().insertAdmin(adminEntity)
            database.approvalTokenDao().markUserApproved(
                userId = myPeerId,
                isApproved = true,
                signature = "ROOT_ADMIN_SELF_AUTHORIZATION",
                adminId = myPeerId,
                timestamp = System.currentTimeMillis()
            )
            database.approvalTokenDao().setAdminRole(myPeerId, true)
            _isAdmin.value = true
            _isApproved.value = true
            Log.i(TAG, "Device successfully designated as Admin Node: $myPeerId")
        }
    }

    /**
     * Starts P2P_CLUSTER Advertising and Discovery over BLE & Wi-Fi Direct.
     */
    fun startMesh() {
        if (_isMeshRunning.value) return
        _isMeshRunning.value = true
        Log.i(TAG, "Starting RebelMesh P2P_CLUSTER for service: $SERVICE_ID")

        startAdvertising()
        startDiscovery()
    }

    /**
     * Stops advertising, discovery, and disconnects all endpoints.
     */
    fun stopMesh() {
        if (!_isMeshRunning.value) return
        _isMeshRunning.value = false
        Log.i(TAG, "Stopping RebelMesh")

        try {
            connectionsClient.stopAdvertising()
            connectionsClient.stopDiscovery()
            connectionsClient.stopAllEndpoints()
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping Nearby Connections", e)
        }

        activeEndpoints.clear()
        peerIdToEndpointMap.clear()
        _connectedPeersCount.value = 0

        scope.launch {
            database.peerDao().markAllDisconnected()
        }
    }

    private fun startAdvertising() {
        val advertisingOptions = AdvertisingOptions.Builder()
            .setStrategy(Strategy.P2P_CLUSTER)
            .build()

        connectionsClient.startAdvertising(
            myDisplayName,
            SERVICE_ID,
            connectionLifecycleCallback,
            advertisingOptions
        ).addOnSuccessListener {
            Log.d(TAG, "RebelMesh Advertising active")
        }.addOnFailureListener { e ->
            Log.e(TAG, "RebelMesh Advertising failed to start", e)
        }
    }

    private fun startDiscovery() {
        val discoveryOptions = DiscoveryOptions.Builder()
            .setStrategy(Strategy.P2P_CLUSTER)
            .build()

        connectionsClient.startDiscovery(
            SERVICE_ID,
            endpointDiscoveryCallback,
            discoveryOptions
        ).addOnSuccessListener {
            Log.d(TAG, "RebelMesh Discovery active")
        }.addOnFailureListener { e ->
            Log.e(TAG, "RebelMesh Discovery failed to start", e)
        }
    }

    // -------------------------------------------------------------------------
    // Nearby Connections Callbacks
    // -------------------------------------------------------------------------

    private val endpointDiscoveryCallback = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
            Log.d(TAG, "Discovered endpoint: $endpointId (${info.endpointName}). Auto-connecting...")
            connectionsClient.requestConnection(
                myDisplayName,
                endpointId,
                connectionLifecycleCallback
            ).addOnFailureListener { e ->
                Log.w(TAG, "Auto-connection request failed for $endpointId: ${e.message}")
            }
        }

        override fun onEndpointLost(endpointId: String) {
            Log.d(TAG, "Discovered endpoint lost: $endpointId")
        }
    }

    private val connectionLifecycleCallback = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            Log.d(TAG, "Connection initiated with endpoint: $endpointId (${info.endpointName}). Accepting...")
            activeEndpoints[endpointId] = ConnectedEndpoint(
                endpointId = endpointId,
                displayName = info.endpointName
            )
            connectionsClient.acceptConnection(endpointId, payloadCallback)
        }

        override fun onConnectionResult(endpointId: String, resolution: ConnectionResolution) {
            when (resolution.status.statusCode) {
                ConnectionsStatusCodes.STATUS_OK -> {
                    Log.i(TAG, "Connection ESTABLISHED with endpoint: $endpointId")
                    sendHandshakePacket(endpointId)
                }
                ConnectionsStatusCodes.STATUS_CONNECTION_REJECTED -> {
                    Log.w(TAG, "Connection rejected by endpoint: $endpointId")
                    activeEndpoints.remove(endpointId)
                }
                else -> {
                    Log.w(TAG, "Connection failed to endpoint: $endpointId with code: ${resolution.status.statusCode}")
                    activeEndpoints.remove(endpointId)
                }
            }
        }

        override fun onDisconnected(endpointId: String) {
            Log.i(TAG, "Endpoint disconnected: $endpointId")
            val endpoint = activeEndpoints.remove(endpointId)
            endpoint?.peerId?.let { peerId ->
                peerIdToEndpointMap.remove(peerId)
                scope.launch {
                    database.peerDao().updateConnectionStatus(
                        peerId = peerId,
                        isConnected = false,
                        endpointId = null,
                        timestamp = System.currentTimeMillis()
                    )
                    _meshEvents.emit(MeshEvent.PeerDisconnected(peerId))
                }
            }
            _connectedPeersCount.value = activeEndpoints.size
        }
    }

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            if (payload.type != Payload.Type.BYTES) return
            val bytes = payload.asBytes() ?: return
            val rawJson = String(bytes, StandardCharsets.UTF_8)

            try {
                val packet = json.decodeFromString<MeshPacket>(rawJson)
                handleIncomingPacket(endpointId, packet, rawJson)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to parse incoming mesh packet from $endpointId", e)
            }
        }

        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {}
    }

    // -------------------------------------------------------------------------
    // Packet Protocol & Mesh Routing Core
    // -------------------------------------------------------------------------

    private fun sendHandshakePacket(endpointId: String) {
        val handshakePacket = MeshPacket(
            type = PacketType.HANDSHAKE,
            senderId = myPeerId,
            senderDisplayName = myDisplayName,
            recipientId = "BROADCAST",
            ttl = 1,
            ciphertext = myPublicKeyBase64
        )
        sendPacketToEndpoint(endpointId, handshakePacket)
    }

    private fun handleIncomingPacket(fromEndpointId: String, packet: MeshPacket, rawJson: String) {
        // Deduplication & Loop Detection
        synchronized(seenPacketIds) {
            if (seenPacketIds.contains(packet.packetId)) {
                Log.d(TAG, "Loop detection: packet ${packet.packetId} already seen. Dropping.")
                return
            }
            if (seenPacketIds.size >= maxSeenPackets) {
                val first = seenPacketIds.iterator().next()
                seenPacketIds.remove(first)
            }
            seenPacketIds.add(packet.packetId)
        }

        when (packet.type) {
            PacketType.HANDSHAKE -> handleHandshakePacket(fromEndpointId, packet)
            PacketType.DATA -> handleDataPacket(fromEndpointId, packet, rawJson)
            PacketType.ACK -> handleAckPacket(fromEndpointId, packet)
            PacketType.JOIN_REQUEST -> handleJoinRequestPacket(fromEndpointId, packet)
            PacketType.ADMIN_APPROVAL_TOKEN -> handleAdminApprovalTokenPacket(fromEndpointId, packet)
            PacketType.ADMIN_REVOCATION -> handleAdminRevocationPacket(fromEndpointId, packet)
        }
    }

    private fun handleHandshakePacket(fromEndpointId: String, packet: MeshPacket) {
        val peerId = packet.senderId
        val displayName = packet.senderDisplayName
        val publicKeyBase64 = packet.ciphertext

        Log.i(TAG, "Handshake completed with peer: $peerId ($displayName)")

        val endpoint = activeEndpoints[fromEndpointId]
        if (endpoint != null) {
            endpoint.peerId = peerId
            endpoint.displayName = displayName
            endpoint.publicKeyBase64 = publicKeyBase64
        }
        peerIdToEndpointMap[peerId] = fromEndpointId
        _connectedPeersCount.value = activeEndpoints.size

        val peerEntity = PeerEntity(
            peerId = peerId,
            displayName = displayName,
            publicKeyBase64 = publicKeyBase64,
            endpointId = fromEndpointId,
            isConnected = true,
            lastSeenTimestamp = System.currentTimeMillis()
        )

        scope.launch {
            database.peerDao().upsertPeer(peerEntity)
            _meshEvents.emit(MeshEvent.PeerConnected(peerEntity))

            // Flush Store-and-Forward queue
            flushPendingStoreAndForwardMessages(peerId)
        }
    }

    private fun handleDataPacket(fromEndpointId: String, packet: MeshPacket, rawJson: String) {
        // Only approved users may decrypt and process regular chat data
        if (!_isApproved.value && packet.recipientId == myPeerId) {
            Log.w(TAG, "Dropping incoming chat message: Local user is not yet approved by an Admin.")
            return
        }

        if (packet.recipientId == myPeerId) {
            Log.i(TAG, "Packet ${packet.packetId} reached destination via ${packet.hopCount} hops")
            try {
                val encryptedPayload = EncryptedPayload(
                    encryptedAesKey = packet.encryptedAesKey,
                    iv = packet.iv,
                    ciphertext = packet.ciphertext
                )
                val decryptedText = CryptoManager.decryptHybrid(encryptedPayload, myPrivateKey)
                val traceSummary = (packet.routeTrace + myDisplayName).joinToString(" -> ")

                val messageEntity = MessageEntity(
                    packetId = packet.packetId,
                    conversationPeerId = packet.senderId,
                    senderId = packet.senderId,
                    recipientId = myPeerId,
                    content = decryptedText,
                    timestamp = packet.timestamp,
                    isOutgoing = false,
                    isDelivered = true,
                    hopCount = packet.hopCount,
                    routeTrace = traceSummary
                )

                scope.launch {
                    database.messageDao().insertMessage(messageEntity)
                    _meshEvents.emit(MeshEvent.MessageReceived(messageEntity))
                    sendAckPacket(packet.senderId, packet.packetId)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to decrypt incoming message payload from ${packet.senderId}", e)
            }
            return
        }

        // Intermediate Relay Node: TTL Loop Control
        relayPacket(fromEndpointId, packet)
    }

    // -------------------------------------------------------------------------
    // Offline Multi-Admin Onboarding Handlers
    // -------------------------------------------------------------------------

    private fun handleJoinRequestPacket(fromEndpointId: String, packet: MeshPacket) {
        Log.i(TAG, "Received JOIN_REQUEST packet ${packet.packetId} from ${packet.senderId}")

        try {
            val joinPayload = JoinRequestPayload.fromJson(packet.ciphertext)
            val fingerprint = CryptoManager.getFingerprint(
                AdminCryptoManager.decodePublicKey(joinPayload.userPublicKey)
            )

            // If this node is an Admin, record the request in the Approval Queue
            if (_isAdmin.value) {
                val requestEntity = ApprovalRequestEntity(
                    userId = joinPayload.userId,
                    username = joinPayload.username,
                    userPublicKeyBase64 = joinPayload.userPublicKey,
                    keyFingerprint = fingerprint,
                    deviceModel = joinPayload.deviceModel,
                    timestamp = joinPayload.timestamp,
                    status = "PENDING",
                    receivedViaNodeId = fromEndpointId,
                    hopCount = packet.hopCount
                )

                scope.launch {
                    database.approvalRequestDao().insertRequest(requestEntity)
                    _meshEvents.emit(MeshEvent.JoinRequestReceived(requestEntity))
                    Log.i(TAG, "Recorded incoming JOIN_REQUEST from ${joinPayload.username} (${joinPayload.userId})")
                }
            }

            // Always forward Join Requests so other Admin nodes on the mesh also receive them
            if (packet.ttl > 1) {
                val nextPacket = packet.copy(
                    ttl = packet.ttl - 1,
                    hopCount = packet.hopCount + 1,
                    routeTrace = packet.routeTrace + myDisplayName
                )
                floodRelay(nextPacket, excludeEndpoint = fromEndpointId)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error processing JOIN_REQUEST packet", e)
        }
    }

    private fun handleAdminApprovalTokenPacket(fromEndpointId: String, packet: MeshPacket) {
        Log.i(TAG, "Received ADMIN_APPROVAL_TOKEN packet ${packet.packetId} destined for ${packet.recipientId}")

        try {
            val tokenPayload = ApprovalTokenPayload.fromJson(packet.ciphertext)

            // Check if THIS node is the pending user being approved!
            if (tokenPayload.userId == myPeerId || packet.recipientId == myPeerId) {
                Log.i(TAG, "Processing ADMIN_APPROVAL_TOKEN issued for THIS node!")

                scope.launch {
                    // 1. Verify that the approving admin is in our trusted admin database
                    val trustedAdmin = database.adminDao().getAdminById(tokenPayload.approvedByAdminId)
                    val adminPublicKey = if (trustedAdmin != null) {
                        AdminCryptoManager.decodePublicKey(trustedAdmin.publicKeyBase64)
                    } else if (tokenPayload.adminPublicKey != null) {
                        AdminCryptoManager.decodePublicKey(tokenPayload.adminPublicKey)
                    } else {
                        null
                    }

                    if (adminPublicKey == null) {
                        Log.w(TAG, "Approval Token rejected: Admin ${tokenPayload.approvedByAdminId} not recognized.")
                        return@launch
                    }

                    // 2. Cryptographically verify the Admin's RSA/SHA-256 digital signature
                    val isValid = AdminCryptoManager.verifyApprovalToken(
                        userId = tokenPayload.userId,
                        userPublicKeyBase64 = myPublicKeyBase64,
                        adminId = tokenPayload.approvedByAdminId,
                        issuedAtTimestamp = tokenPayload.issuedAtTimestamp,
                        signatureBase64 = tokenPayload.signature,
                        adminPublicKey = adminPublicKey
                    )

                    if (isValid) {
                        Log.i(TAG, "Cryptographic signature VERIFIED! Unlocking RebelMesh application offline.")

                        val tokenEntity = ApprovalTokenEntity(
                            userId = tokenPayload.userId,
                            approvedByAdminId = tokenPayload.approvedByAdminId,
                            issuedAtTimestamp = tokenPayload.issuedAtTimestamp,
                            signatureBase64 = tokenPayload.signature,
                            isVerifiedLocally = true,
                            rawCanonicalPayload = packet.ciphertext
                        )
                        database.approvalTokenDao().insertToken(tokenEntity)

                        database.approvalTokenDao().markUserApproved(
                            userId = myPeerId,
                            isApproved = true,
                            signature = tokenPayload.signature,
                            adminId = tokenPayload.approvedByAdminId,
                            timestamp = tokenPayload.issuedAtTimestamp
                        )

                        _isApproved.value = true
                        _meshEvents.emit(MeshEvent.UserApproved(tokenEntity))
                    } else {
                        Log.e(TAG, "Approval signature verification FAILED! Tampered token detected.")
                    }
                }
                return
            }

            // Intermediate Relay Node: Forward Approval Token towards pending user
            relayPacket(fromEndpointId, packet)
        } catch (e: Exception) {
            Log.e(TAG, "Error handling ADMIN_APPROVAL_TOKEN packet", e)
        }
    }

    private fun handleAdminRevocationPacket(fromEndpointId: String, packet: MeshPacket) {
        try {
            val revocation = RevocationPayload.fromJson(packet.ciphertext)
            scope.launch {
                val admin = database.adminDao().getAdminById(revocation.revokedByAdminId)
                if (admin != null) {
                    val adminKey = AdminCryptoManager.decodePublicKey(admin.publicKeyBase64)
                    val isValid = AdminCryptoManager.verifyRevocation(
                        targetUserId = revocation.targetUserId,
                        adminId = revocation.revokedByAdminId,
                        timestamp = revocation.timestamp,
                        reason = revocation.reason,
                        signatureBase64 = revocation.signature,
                        adminPublicKey = adminKey
                    )

                    if (isValid) {
                        Log.i(TAG, "Verified revocation for peer ${revocation.targetUserId}")
                        if (revocation.targetUserId == myPeerId) {
                            database.approvalTokenDao().setAdminRole(myPeerId, false)
                            _isApproved.value = false
                        }
                        database.approvalRequestDao().updateRequestStatus(
                            userId = revocation.targetUserId,
                            status = "REJECTED",
                            adminId = revocation.revokedByAdminId,
                            timestamp = revocation.timestamp
                        )
                        _meshEvents.emit(MeshEvent.UserRevoked(revocation.targetUserId, revocation.revokedByAdminId))
                    }
                }
            }

            relayPacket(fromEndpointId, packet)
        } catch (e: Exception) {
            Log.e(TAG, "Error handling ADMIN_REVOCATION packet", e)
        }
    }

    private fun relayPacket(fromEndpointId: String, packet: MeshPacket) {
        if (packet.ttl <= 1) {
            Log.w(TAG, "Packet ${packet.packetId} TTL expired. Dropping packet.")
            return
        }

        val nextTtl = packet.ttl - 1
        val nextHopCount = packet.hopCount + 1
        val updatedTrace = packet.routeTrace + myDisplayName

        val relayedPacket = packet.copy(
            ttl = nextTtl,
            hopCount = nextHopCount,
            routeTrace = updatedTrace
        )

        scope.launch {
            _meshEvents.emit(
                MeshEvent.PacketRelayed(
                    packetId = packet.packetId,
                    senderId = packet.senderId,
                    recipientId = packet.recipientId,
                    hopsLeft = nextTtl
                )
            )

            val targetEndpoint = peerIdToEndpointMap[packet.recipientId]
            if (targetEndpoint != null) {
                sendPacketToEndpoint(targetEndpoint, relayedPacket)
            } else {
                val pendingEntity = PendingRelayEntity(
                    packetId = packet.packetId,
                    recipientId = packet.recipientId,
                    rawPacketJson = json.encodeToString(relayedPacket),
                    ttl = nextTtl
                )
                database.pendingRelayDao().insertPending(pendingEntity)
                floodRelay(relayedPacket, excludeEndpoint = fromEndpointId)
            }
        }
    }

    private fun handleAckPacket(fromEndpointId: String, packet: MeshPacket) {
        val targetPacketId = packet.ciphertext
        Log.i(TAG, "Delivery ACK received for message: $targetPacketId")

        scope.launch {
            database.messageDao().updateDeliveryStatus(targetPacketId, true)
            database.pendingRelayDao().deletePending(targetPacketId)
            _meshEvents.emit(MeshEvent.DeliveryAckReceived(targetPacketId))

            if (packet.recipientId != myPeerId && packet.ttl > 1) {
                val forwardedAck = packet.copy(ttl = packet.ttl - 1)
                val targetEndpoint = peerIdToEndpointMap[packet.recipientId]
                if (targetEndpoint != null) {
                    sendPacketToEndpoint(targetEndpoint, forwardedAck)
                } else {
                    floodRelay(forwardedAck, excludeEndpoint = fromEndpointId)
                }
            }
        }
    }

    private fun sendAckPacket(recipientId: String, originalPacketId: String) {
        val ackPacket = MeshPacket(
            type = PacketType.ACK,
            senderId = myPeerId,
            senderDisplayName = myDisplayName,
            recipientId = recipientId,
            ttl = MAX_TTL,
            ciphertext = originalPacketId
        )

        val directEndpoint = peerIdToEndpointMap[recipientId]
        if (directEndpoint != null) {
            sendPacketToEndpoint(directEndpoint, ackPacket)
        } else {
            floodRelay(ackPacket)
        }
    }

    // -------------------------------------------------------------------------
    // Public API for UI Screens (Join Requests, Admin Approval, Chat Messaging)
    // -------------------------------------------------------------------------

    /**
     * Broadcasts an unapproved user's Join Request across the mesh to reach an Admin node.
     */
    fun broadcastJoinRequest(username: String, onComplete: (Boolean) -> Unit = {}) {
        scope.launch {
            try {
                val payload = JoinRequestPayload(
                    userId = myPeerId,
                    username = username,
                    userPublicKey = myPublicKeyBase64,
                    timestamp = System.currentTimeMillis(),
                    deviceModel = Build.MODEL ?: "Android",
                    status = "PENDING"
                )

                val packet = MeshPacket(
                    packetId = UUID.randomUUID().toString(),
                    type = PacketType.JOIN_REQUEST,
                    senderId = myPeerId,
                    senderDisplayName = username,
                    recipientId = BROADCAST_ADMINS,
                    ttl = MAX_TTL,
                    hopCount = 1,
                    routeTrace = listOf(username),
                    ciphertext = payload.toJson(),
                    timestamp = System.currentTimeMillis()
                )

                floodRelay(packet)
                Log.i(TAG, "Broadcasted JOIN_REQUEST packet across mesh for $username")
                onComplete(true)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to broadcast join request", e)
                onComplete(false)
            }
        }
    }

    /**
     * Issues an RSA-SHA256 digitally signed Approval Token and broadcasts it back to the pending user.
     */
    fun approveUserRegistration(userId: String, onComplete: (Boolean) -> Unit = {}) {
        scope.launch {
            try {
                val request = database.approvalRequestDao().getRequestByUserId(userId)
                if (request == null) {
                    Log.w(TAG, "Cannot approve: Request for $userId not found.")
                    onComplete(false)
                    return@launch
                }

                val issuedAt = System.currentTimeMillis()
                // Cryptographically sign the user's identity and public key using Admin Private Key
                val signature = AdminCryptoManager.signApprovalToken(
                    userId = request.userId,
                    userPublicKeyBase64 = request.userPublicKeyBase64,
                    adminId = myPeerId,
                    issuedAtTimestamp = issuedAt,
                    adminPrivateKey = myPrivateKey
                )

                val tokenPayload = ApprovalTokenPayload(
                    userId = request.userId,
                    username = request.username,
                    approvedByAdminId = myPeerId,
                    issuedAtTimestamp = issuedAt,
                    signature = signature,
                    adminPublicKey = myPublicKeyBase64
                )

                val tokenPacket = MeshPacket(
                    packetId = UUID.randomUUID().toString(),
                    type = PacketType.ADMIN_APPROVAL_TOKEN,
                    senderId = myPeerId,
                    senderDisplayName = myDisplayName,
                    recipientId = request.userId,
                    ttl = MAX_TTL,
                    hopCount = 1,
                    routeTrace = listOf(myDisplayName),
                    ciphertext = tokenPayload.toJson(),
                    timestamp = issuedAt
                )

                // Update local Room database
                database.approvalRequestDao().updateRequestStatus(
                    userId = request.userId,
                    status = "APPROVED",
                    adminId = myPeerId,
                    timestamp = issuedAt
                )

                // Transmit directly or queue & flood
                val directEndpoint = peerIdToEndpointMap[request.userId]
                if (directEndpoint != null) {
                    sendPacketToEndpoint(directEndpoint, tokenPacket)
                } else {
                    val pending = PendingRelayEntity(
                        packetId = tokenPacket.packetId,
                        recipientId = request.userId,
                        rawPacketJson = json.encodeToString(tokenPacket),
                        ttl = MAX_TTL
                    )
                    database.pendingRelayDao().insertPending(pending)
                    floodRelay(tokenPacket)
                }

                Log.i(TAG, "Issued and broadcasted Approval Token for user ${request.username} ($userId)")
                onComplete(true)
            } catch (e: Exception) {
                Log.e(TAG, "Error approving user registration", e)
                onComplete(false)
            }
        }
    }

    /**
     * Rejects an unapproved user registration.
     */
    fun rejectUserRegistration(userId: String, onComplete: (Boolean) -> Unit = {}) {
        scope.launch {
            try {
                database.approvalRequestDao().updateRequestStatus(
                    userId = userId,
                    status = "REJECTED",
                    adminId = myPeerId,
                    timestamp = System.currentTimeMillis()
                )
                onComplete(true)
            } catch (e: Exception) {
                onComplete(false)
            }
        }
    }

    private suspend fun flushPendingStoreAndForwardMessages(peerId: String) {
        val pendingList = database.pendingRelayDao().getPendingForRecipient(peerId)
        if (pendingList.isEmpty()) return

        val endpointId = peerIdToEndpointMap[peerId] ?: return
        Log.i(TAG, "Flushing ${pendingList.size} Store-and-Forward packets for peer $peerId")

        for (pending in pendingList) {
            try {
                val packet = json.decodeFromString<MeshPacket>(pending.rawPacketJson)
                sendPacketToEndpoint(endpointId, packet)
                database.pendingRelayDao().deletePending(pending.packetId)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to push queued message ${pending.packetId}", e)
            }
        }
    }

    fun sendMessage(recipientPeer: PeerEntity, text: String, onComplete: (Boolean) -> Unit = {}) {
        scope.launch {
            try {
                val recipientKey = CryptoManager.importPublicKey(recipientPeer.publicKeyBase64)
                val encryptedPayload = CryptoManager.encryptHybrid(text, recipientKey)

                val packetId = UUID.randomUUID().toString()
                val packet = MeshPacket(
                    packetId = packetId,
                    type = PacketType.DATA,
                    senderId = myPeerId,
                    senderDisplayName = myDisplayName,
                    recipientId = recipientPeer.peerId,
                    ttl = MAX_TTL,
                    hopCount = 1,
                    routeTrace = listOf(myDisplayName),
                    encryptedAesKey = encryptedPayload.encryptedAesKey,
                    iv = encryptedPayload.iv,
                    ciphertext = encryptedPayload.ciphertext,
                    timestamp = System.currentTimeMillis()
                )

                val messageEntity = MessageEntity(
                    packetId = packetId,
                    conversationPeerId = recipientPeer.peerId,
                    senderId = myPeerId,
                    recipientId = recipientPeer.peerId,
                    content = text,
                    timestamp = packet.timestamp,
                    isOutgoing = true,
                    isDelivered = false,
                    hopCount = 1,
                    routeTrace = "Direct"
                )
                database.messageDao().insertMessage(messageEntity)

                val directEndpoint = peerIdToEndpointMap[recipientPeer.peerId]
                if (directEndpoint != null) {
                    sendPacketToEndpoint(directEndpoint, packet)
                    Log.i(TAG, "Sent message $packetId directly to ${recipientPeer.peerId}")
                } else {
                    val pendingEntity = PendingRelayEntity(
                        packetId = packetId,
                        recipientId = recipientPeer.peerId,
                        rawPacketJson = json.encodeToString(packet),
                        ttl = MAX_TTL
                    )
                    database.pendingRelayDao().insertPending(pendingEntity)
                    floodRelay(packet)
                    Log.i(TAG, "Queued message $packetId in Store-and-Forward & flooded mesh")
                }

                onComplete(true)
            } catch (e: Exception) {
                Log.e(TAG, "Error encrypting or sending message", e)
                onComplete(false)
            }
        }
    }

    private fun floodRelay(packet: MeshPacket, excludeEndpoint: String? = null) {
        val targets = activeEndpoints.keys.filter { it != excludeEndpoint }
        for (target in targets) {
            sendPacketToEndpoint(target, packet)
        }
    }

    private fun sendPacketToEndpoint(endpointId: String, packet: MeshPacket) {
        try {
            val rawJson = json.encodeToString(packet)
            val payload = Payload.fromBytes(rawJson.toByteArray(StandardCharsets.UTF_8))
            connectionsClient.sendPayload(endpointId, payload).addOnFailureListener { e ->
                Log.w(TAG, "Failed to send payload to endpoint $endpointId: ${e.message}")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error encoding or sending payload to $endpointId", e)
        }
    }
}
